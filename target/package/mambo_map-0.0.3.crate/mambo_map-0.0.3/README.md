A very simple and cross-platform implementation of the cache table framework that uses only use std::{
mem,
    sync::{Arc, Mutex, RwLock, TryLockError},
} set of the standard rust library